# Annie Zheng — Analyst Portfolio

Financial analysis, valuation research, management reporting and operations analytics.

## Financial reporting and management review

During my Sweet Bamboo internship, I developed a monthly P&L process to make revenue, expenses and store profitability more transparent. I organized transaction exports into consistent categories, incorporated exception review and built monthly comparisons to help management identify cost drivers.

The public work samples use fictional stores and newly generated financial inputs. They demonstrate the reporting method, monthly variances, operating result bridge and measurement framework. Financial improvement is evaluated separately from reporting visibility.

Files:
- `Financial_Reporting_Demo.pptx` — 10-slide management presentation.
- `Restaurant_Management_Review_Demo.pdf` — five-page monthly review of three illustrative stores.
- `Restaurant_Monthly_Review_Demo.xlsx` — editable inputs, formula-based financial comparisons and management summary.

## Inventory and purchasing

I developed a sales-driven replenishment workflow for Sweet Bamboo using POS reports, Google Sheets and Apps Script. The workflow maps menu sales to ingredient requirements and supplier units, helping managers prepare orders with a more consistent view of expected usage and stock.

The public workbook is a compact reconstruction with 14 sales days, five fictional menu items and four invented ingredients. It demonstrates mapping, recipe quantities, package conversions, expected stock and purchase calculations. Physical counts remain necessary because sales-based usage is an estimate. Production email ingestion and Apps Script triggers are described rather than embedded in the Excel file.

Files:
- `Inventory_Management_Demo.pptx` — 12-slide presentation covering the workflow, calculations, controls and measurement plan.
- `Inventory_Purchasing_Demo.xlsx` — 12 linked worksheets with editable inputs and formula-based purchasing logic.

## Marketplace and direct-channel economics

This scenario analysis evaluates how migrating marketplace sales to direct ordering and changing delivery arrangements affect contribution. It separates avoided commissions and advertising from incremental provider fees, discounts and delivery costs.

All inputs are hypothetical. Scenario results represent modeled estimates, rather than measured savings. Total sales are held constant so the model isolates the assumed channel and cost changes.

File:
- `Marketplace_Savings_Demo.xlsx` — editable scenarios and gross-to-net benefit calculations.

## Company valuation research

These independent valuation studies connect operating drivers to financial forecasts, cash flow, invested capital and estimated equity value. Each report includes a DCF, an EV/EBITD valuation, assumptions, methodology and source notes. E identifies an analyst estimate; reference prices are model inputs rather than live quotations.

Files:
- `Starbucks_Valuation_Analysis.pdf` — regional store and revenue forecasts, margin recovery, cash flow and valuation. The methodology appendix distinguishes the analytical income statement from reported earnings.
- `Colgate_Valuation_Analysis.pdf` — regional revenue, adjusted earnings, cash flow, cost of capital and valuation. The appendix reconciles reported and adjusted earnings and states the CAPM beta assumption.
- `Costco_Valuation_Analysis.pdf` — warehouse growth, sales productivity, membership revenue and valuation. The appendix includes a discount-rate and terminal-growth sensitivity table.

## Data and methods

Restaurant samples are portfolio adaptations of internship work. Financial values, store identities, menu items, recipes and stock records are fictional. They illustrate methods without disclosing actual operating records. Added scenario costs, controls and validation examples form part of the public demonstration; they do not establish measured internship outcomes.

Public-company studies retain company names to identify the subjects. Their financial statements and earnings definitions are referenced to the relevant SEC filings in each report. Model earnings are labeled separately where the analytical build differs from reported earnings.

Author: Annie Zheng
