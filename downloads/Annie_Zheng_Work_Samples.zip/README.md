# Annie Zheng — Portfolio

Projects from my Sweet Bamboo internship and company valuation research.

## Monthly P&L reporting
I organized transaction exports into financial categories and built a monthly P&L so managers could review store profitability and cost changes. The files include a presentation, a management report and an editable workbook.

## Inventory and purchasing
I used daily MenuSifu reports, menu mappings and Apps Script to support purchasing. The public Excel workbook is a compact reconstruction with example inputs. Live email ingestion is described in the presentation.

## Marketplace commission analysis
I compared direct-order and own-driver delivery scenarios. The workbook separates avoided platform costs from extra fees, discounts and delivery costs. Its outputs are estimates.

## Company valuations
Reports on Starbucks, Colgate-Palmolive and Costco cover operating forecasts, cash flow, DCF and enterprise-value multiples. Each report includes methodology and source notes.

## Data note
Restaurant financial and inventory records have been replaced with example data for confidentiality. These are illustrative datasets, rather than proportional rescalings of actual results. Their numerical results are not measured internship outcomes. Public-company figures retain their financial meaning and are identified separately from model estimates.

Author: Annie Zheng
